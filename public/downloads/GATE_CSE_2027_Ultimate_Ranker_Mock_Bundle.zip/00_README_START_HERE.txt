========================================================================
  GATE CSE 2027 ULTIMATE RANKER BUNDLE — OFFICIAL PACK
  10 Predicted Mocks + 10 Worked Solutions + Repeated Patterns + CBT
========================================================================

Thank you for your purchase from gate2026!

WHAT IS INCLUDED IN YOUR BUNDLE:
------------------------------------------------------------------------
1. [01_TCS_iON_CBT_Simulator]
   - GATE_CSE_2027_CBT_Simulator.html
   - Full 180-minute TCS iON exam engine simulator with virtual scientific
     calculator, question palette (Answered, Marked for Review, Not Visited),
     instant auto-scoring, topic-wise accuracy breakdown, and detailed explanations.
   - Works 100% OFFLINE! Just double click to open in Chrome, Brave, Edge or Firefox.

2. [02_Master_Complete_Mock_Book]
   - GATE_CSE_2027_10_Predicted_Mocks_Complete.pdf (Master 400+ Page Volume)
   - Contains all 10 Predicted Full-Length Mock Papers + complete step-by-step
     worked solutions bound in one unified, searchable, printable PDF.

3. [03_Repeated_Patterns_Monograph]
   - GATE_CSE_2027_Questions_GATE_Repeats_90Day.pdf
   - The 90-Day High-Yield Blueprint: 60 recurring question blueprints ranked
     by frequency across 35 years of GATE CSE PYQs with NAT trap warnings.

4. [04_Individual_Mock_Question_Papers]
   - Mock_01 through Mock_10 Question Papers (individual clean PDFs for timed practice).

5. [05_Individual_Worked_Solutions]
   - Mock_01 through Mock_10 Worked Solutions (complete explanations for post-exam review).

HOW TO PREPARE FOR BEST RESULTS:
------------------------------------------------------------------------
Step 1: Open the CBT Simulator or print Mock_01_Question_Paper.pdf.
Step 2: Sit in an isolated 3-hour exam block (9:30 AM - 12:30 PM or 2:30 PM - 5:30 PM).
Step 3: Strictly use the on-screen virtual calculator (no physical calculator).
Step 4: After completing, open the corresponding Solutions PDF to diagnose mistakes.
Step 5: Revise identified weak topics using the Repeated Patterns Monograph.

Support & Inquiries: lessgo.dsa@gmail.com
Store: gate2026
========================================================================
